import React from 'react';
import SchoolList from '../components/Parent/SchoolList';

const ParentPage = () => {
  return (
    <div>
      <h1>Parent Page</h1>
      <SchoolList />
    </div>
  );
};

export default ParentPage;
