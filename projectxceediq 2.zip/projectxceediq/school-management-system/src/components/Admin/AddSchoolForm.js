import React, { useState } from 'react';
import { postSchool } from '../../api';

const AddSchoolForm = () => {
  const [schoolName, setSchoolName] = useState('');
  const [schoolFees, setSchoolFees] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await postSchool({ name :schoolName, fees:schoolFees });
      // Add success notification or redirection logic
    } catch (err) {
      console.error('Error adding school:', err);
      // Add error notification logic
    }
  };

  return (
    <div>
      <h2>Add School</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="School Name" value={schoolName} onChange={(e) => setSchoolName(e.target.value)} />
        <input type="number" placeholder="School Fees" value={schoolFees} onChange={(e) => setSchoolFees(e.target.value)} />
        <button type="submit">Add School</button>
      </form>
    </div>
  );
};

export default AddSchoolForm;
