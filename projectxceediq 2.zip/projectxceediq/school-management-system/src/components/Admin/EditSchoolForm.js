import React, { useState } from 'react';
import { putSchool } from '../../api';

const AddSchoolForm = (prop1) => {
  const [schoolName, setSchoolName] = useState('');
  const [schoolFees, setSchoolFees] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log(prop1);
      await putSchool({ name:schoolName, fees:schoolFees });
      // Add success notification or redirection logic
    } catch (err) {
      console.error('Error adding school:', err);
      // Add error notification logic
    }
  };

  return (
    <div>
      <h2>Edit School</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="School Name" value={schoolName} onChange={(e) => setSchoolName(e.target.value)} />
        <input type="number" placeholder="School Fees" value={schoolFees} onChange={(e) => setSchoolFees(e.target.value)} />
        <button type="submit">Edit School</button>
      </form>
    </div>
  );
};

export default AddSchoolForm;
