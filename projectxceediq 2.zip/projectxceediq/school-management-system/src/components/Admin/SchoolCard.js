import React from 'react';
import { deleteSchool } from '../../api';
import Popup from 'reactjs-popup';
import {useState,useEffect} from 'react'
import EditSchoolForm from './EditSchoolForm';
import classes from "./SchoolCard.css"



const SchoolCard = ({ school }) => {
  const [popup,setPop]=useState()
 

  const Delete = async (school1) => {
    

    try {
      console.log(school1);
      await deleteSchool( school1 );
      console.log("success");
      // Add success notification or redirection logic
    } catch (err) {
      console.error('Error adding school:', err);
      // Add error notification logic
    }
  };


  return (
    <div>
      <h3>{school.name}</h3>
      <p>Fees: ${school.fees}</p>
      <button onClick={()=>{Delete(school.name)}}>Delete</button>
      <button onClick={()=>{ setPop(true)}}>edit</button>

      {/* Add other school details */}
      {/* Implement edit and delete functionality */}
      <Popup
                            open={popup} 
                            modal
                            nested
                
                          >
                            
                            {<div> <EditSchoolForm   />  <button onClick={() => setPop(false)} variant="contained">
                                    Close 
                                  </button> </div>}
                          </Popup>
    </div>
  );
};

export default SchoolCard;
